package com.northbridgeanalytics.mysensors;

// Fontes
// https://code.tutsplus.com/tutorials/using-the-accelerometer-on-android--mobile-22125
// https://google-developer-training.gitbooks.io/android-developer-advanced-course-practicals/content/unit-1-expand-the-user-experience/lesson-3-sensors/3-2-p-working-with-sensor-based-orientation/3-2-p-working-with-sensor-based-orientation.html
// https://stackoverflow.com/questions/5464847/transforming-accelerometers-data-from-devices-coordinates-to-real-world-coordi
// https://stackoverflow.com/questions/23701546/android-get-accelerometers-on-earth-coordinate-system
// https://stackoverflow.com/questions/11578636/acceleration-from-devices-coordinate-system-into-absolute-coordinate-system

import SurfaceDoctor.SegmentHandler;
import SurfaceDoctor.SurfaceDoctorEvent;
import SurfaceDoctor.SurfaceDoctorInterface;
import android.content.SharedPreferences;
import android.os.Build;
import android.support.v4.app.FragmentManager;
import android.view.Menu;
import android.view.MenuItem;
import android.view.WindowManager;
import myAlerts.AlertDialogGPS;
import SurfaceDoctor.VectorAlgebra;
import android.Manifest;
import android.content.Context;
import android.content.pm.ActivityInfo;
import android.content.pm.PackageManager;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.support.v4.app.ActivityCompat;
import android.support.v4.content.ContextCompat;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import org.osmdroid.api.IMapController;
import org.osmdroid.tileprovider.tilesource.TileSourceFactory;
import org.osmdroid.util.GeoPoint;
import org.osmdroid.views.MapController;
import org.osmdroid.views.MapView;
import org.osmdroid.views.overlay.Marker;

import static android.preference.PreferenceManager.getDefaultSharedPreferences;

// TODO: https://blog.fossasia.org/comparing-different-graph-view-libraries-and-integrating-them-in-pslab-android-application/


public class MainActivity extends AppCompatActivity
        implements SensorEventListener, LocationListener, SurfaceDoctorInterface {

    // Código de retorno de chamada para permissões de GPS.
    private static final int MY_PERMISSIONS_REQUEST_ACCESS_FINE_LOCATION = 1;
    private FragmentManager fm = getSupportFragmentManager();

    private float[] adjustedGravity = new float[3];
    private float[] linear_acceleration = new float[3];


    private MapView osm;
    private MapController mc;

    // Valores muito pequenos para o acelerômetro (nos três eixos) devem ser interpretados como 0. Este valor é a quantidade de desvio diferente de zero aceitável.
    private static final float VALUE_DRIFT = 0.05f;

    // TextViews para exibir os valores atuais do sensor.
    private TextView TextSensorPhoneAccX;
    private TextView TextSensorPhoneAccY;
    private TextView TextSensorPhoneAccZ;

    private TextView TextSensorEarthAccX;
    private TextView TextSensorEarthAccY;
    private TextView TextSensorEarthAccZ;

    private TextView TextSensorPhoneAzimuth;
    private TextView TextSensorPhonePitch;
    private TextView TextSensorPhoneRoll;

    // Instância do gerenciador de sensores do sistema.
    private SensorManager SensorManager;
    private LocationManager locationManager;
    private SegmentHandler segmentHandler;

    // Sensores de acelerômetro e magnetômetro, conforme recuperados do gerenciador de sensores.
    private Sensor SensorAccelerometer;
    private Sensor SensorMagnetometer;
    private Sensor SensorGravity;

    // Variáveis para manter os valores atuais do sensor.
    private float[] AccelerometerData = new float[3];
    private float[] MagnetometerData = new float[3];
    private float[] GravityData = new float[3];

    // Variáveis para manter os valores atuais da localização.
    private double currentLatitude;
    private double currentLongitude;

    // Botão para alternar o registro do GPS.
    private Button toggleRecordingButton;
    private boolean isToggleRecordingButtonClicked = false;

    //  Clique para alternar o registro do GPS.
    private View.OnClickListener toggleRecordingListener = new View.OnClickListener() {
        @Override
        public void onClick(View v) {

            // TODO: O usuário precisa de feedback visual do estado atual do botão.
            // TODO: Os booleanos precisam ser movidos para o final da função. Eles podem ser um retorno da função?
            if (!isToggleRecordingButtonClicked) {
                toggleRecordingClickedOn();
            } else {
                toggleRecordingClickedOff();
            }
        }
    };


    //******************************************************************************************************************
    //                                            Ciclo de Vida da Atividade
    //******************************************************************************************************************

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);

        // O código verifica se o aplicativo tem permissões para acessar a internet e escrever no armazenamento externo, se o usuário ainda não tiver cedido as permissões será aberta uma janela de diálogo padrão do Android para solicitar as permissões.
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.INTERNET) != PackageManager.PERMISSION_GRANTED ||
                    ContextCompat.checkSelfPermission(this, Manifest.permission.WRITE_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED) {
                String[] permissoes = {Manifest.permission.INTERNET, Manifest.permission.WRITE_EXTERNAL_STORAGE};
                requestPermissions(permissoes, 1);
            }
        }

        // Adicionando o OpenStreetMap
        //Pega o mapa adicionada no arquivo activity_main.xml
        MapView mapa = (MapView) findViewById(R.id.mapView);
        //Fonte de imagens
        mapa.setTileSource(TileSourceFactory.MAPNIK);
        //Cria um ponto de referência com base na latitude e longitude
        GeoPoint pontoInicial = new GeoPoint(-7.082433, -41.468516);
        IMapController mapController = mapa.getController();
        //Faz zoom no mapa
        mapController.setZoom(15);
        //Centraliza o mapa no ponto de referência
        mapController.setCenter(pontoInicial);


        //Cria um marcador no mapa
        Marker startMarker = new Marker(mapa);
        startMarker.setPosition(pontoInicial);
        startMarker.setTitle("Ponto Inicial");
        //Posição do ícone
        startMarker.setAnchor(Marker.ANCHOR_CENTER, Marker.ANCHOR_BOTTOM);
        mapa.getOverlays().add(startMarker);

        /*
        osm = (MapView) findViewById(R.id.mapView);
        osm.setTileSource(TileSourceFactory.MAPNIK);
        osm.setBuiltInZoomControls(true);
        osm.setMultiTouchControls(true);

        mc = (MapController) osm.getController();
        mc.setZoom(12);


        GeoPoint center = new GeoPoint(0,0);
        mc.animateTo(center);
        addMarker(center); */

        // Bloqueia a orientação para retrato
        setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_PORTRAIT);

        // Obtem a visualização do botão de gravação inicial.
        toggleRecordingButton = findViewById(R.id.toggleRecording);

        // Define quando clicar para a visualização do botão iniciar a gravação.
        toggleRecordingButton.setOnClickListener(toggleRecordingListener);

        // Obtem os TextViews que mostrarão os valores do sensor.
        TextSensorPhoneAccX = (TextView) findViewById(R.id.phone_acc_x);
        TextSensorPhoneAccY = (TextView) findViewById(R.id.phone_acc_y);
        TextSensorPhoneAccZ = (TextView) findViewById(R.id.phone_acc_z);
        TextSensorEarthAccX = (TextView) findViewById(R.id.earth_acc_x);
        TextSensorEarthAccY = (TextView) findViewById(R.id.earth_acc_y);
        TextSensorEarthAccZ = (TextView) findViewById(R.id.earth_acc_z);
        TextSensorPhoneAzimuth = (TextView) findViewById(R.id.phone_azimuth);
        TextSensorPhonePitch = (TextView) findViewById(R.id.phone_pitch);
        TextSensorPhoneRoll = (TextView) findViewById(R.id.phone_roll);


        // Obtem sensores acelerômetro e magnetômetro do gerenciador de sensores.
        // O método getDefaultSensor () retornará nulo se o sensor não estiver disponível no dispositivo.
        SensorManager = (SensorManager) getSystemService(
                Context.SENSOR_SERVICE);
        SensorAccelerometer = SensorManager.getDefaultSensor(
                Sensor.TYPE_ACCELEROMETER);
        SensorMagnetometer = SensorManager.getDefaultSensor(
                Sensor.TYPE_MAGNETIC_FIELD);
        SensorGravity = SensorManager.getDefaultSensor(
                Sensor.TYPE_GRAVITY);

        // Obtem o Gerenciador de localização.
        locationManager = (LocationManager) this.getSystemService(Context.LOCATION_SERVICE);

        Log.i("Activity", "OnCreate has fired");
    }
    // Adicionando um marcador no openStreetMap
    public void addMarker(GeoPoint center){
        Marker marker = new Marker(osm);
        marker.setPosition(center);
        marker.setAnchor(Marker.ANCHOR_CENTER, Marker.ANCHOR_BOTTOM);
        marker.setIcon(getResources().getDrawable(R.drawable.ic_launcher_background));

        osm.getOverlays().clear();
        osm.getOverlays().add(marker);
        osm.invalidate();
    }

    /**
     * Os ouvintes dos sensores são registrados neste retorno de chamada para que
     * eles podem não ser registrados em onStop ().
     */
    @Override
    protected void onStart() {
        super.onStart();

        // Os ouvintes dos sensores são registrados neste retorno de chamada e
        // pode ser não registrado em onStop ().
        //
        // Verifica se os sensores estão disponíveis antes de registrar os ouvintes.
        // Ambos os ouvintes são registrados com uma quantidade "normal" de atraso
        // (SENSOR_DELAY_NORMAL).
        // TODO: Precisa de uma caixa de diálogo informando que os sensores não estão disponíveis.
        if (SensorAccelerometer != null) {
            SensorManager.registerListener(this, SensorAccelerometer,
                    SensorManager.SENSOR_DELAY_FASTEST);
        }
        if (SensorMagnetometer != null) {
            SensorManager.registerListener(this, SensorMagnetometer,
                    SensorManager.SENSOR_DELAY_FASTEST);
        }
        if (SensorManager != null) {
            SensorManager.registerListener(this, SensorGravity,
                    SensorManager.SENSOR_DELAY_FASTEST);
        }

        Log.i("Activity", "OnStart has fired");
    }

    @Override
    protected void onResume() {
        super.onResume();

        Log.i("Activity", "onResume has fired");

    }

    @Override
    protected void onPause() {
        super.onPause();

        Log.i("Activity", "onPause has fired");
    }

    @Override
    protected void onStop() {
        super.onStop();

        // Cancela o registro de todos os ouvintes do sensor nesse retorno de chamada para que eles não continuem usando os recursos quando o aplicativo for parado.
        SensorManager.unregisterListener(this);

        Log.i("Activity", "OnStop has fired");
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();

        Log.i("Activity", "onDestroy has fired");
    }


    //******************************************************************************************************************
    //                                           PERMISSÕES E CONFIGURAÇÕES
    //******************************************************************************************************************

    // Para de registrar quando o usuário desligar o GPS.
    private void toggleRecordingClickedOff() {
        // Desativa as atualizações do LocationListener.
        locationManager.removeUpdates(this);
        isToggleRecordingButtonClicked = false;

        // O usuário não deseja mais gravar o IRI, então vamos excluí-lo.
        segmentHandler = null;

    }


    // O usuário ativou o registro GPS.
    private void toggleRecordingClickedOn() {

        // Verifica se temos permissão para usar o GPS e solicite-o, se não o fizermos.
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION)
                != PackageManager.PERMISSION_GRANTED) {

            // Não temos permissões, é melhor perguntar.
            ActivityCompat.requestPermissions(MainActivity.this,
                    new String[]{Manifest.permission.ACCESS_FINE_LOCATION},
                    MY_PERMISSIONS_REQUEST_ACCESS_FINE_LOCATION);
            // MY_PERMISSIONS_REQUEST_ACCESS_FINE_LOCATION é uma constante inteira que usaremos para procurar o
            // resultado dessa solicitação no retorno de chamada onRequestPermissionsResult ().

        } else {
            // Já temos permissão, então vamos ativar o GPS.
            enableGPS();
        }
    }


    /**
     * Retorno de chamada do Android para uma resposta às solicitações de permissão.
     *
     * @param requestCode
     * @param permissions
     * @param grantResults
     */
    @Override
    public void onRequestPermissionsResult(int requestCode,
                                           String permissions[], int[] grantResults) {
        switch (requestCode) {
            case MY_PERMISSIONS_REQUEST_ACCESS_FINE_LOCATION: {
                // Se a solicitação for cancelada, as matrizes de resultados estarão vazias.
                if (grantResults.length > 0
                        && grantResults[0] == PackageManager.PERMISSION_GRANTED) {

                    // Pede permissão ao usuário e ele diz que sim.
                    enableGPS();

                } else {
                    // ele disse que não.

                    // Como nada resultou do pressionamento do botão, vamos torná-lo para falso.
                    isToggleRecordingButtonClicked = false;

                    // TODO: Algo precisa acontecer se eles negarem permissões.
                    // Permissão negada! Desative a funcionalidade que depende dessa permissão.
                }
                return;
            }
        }
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        switch (requestCode) {
            case 1: {
                // Se a solicitação de permissão foi cancelada o array vem vazio.
                if (grantResults.length > 0
                        && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                    // Permissão cedida, recria a activity para carregar o mapa, só será executado uma vez
                    this.recreate();

                }

            }
        }
    }


    // Depois de obter permissão, ativa o GPS.
    private void enableGPS() {
        // Verifica se o usuário tem o GPS ativado.
        if (!locationManager.isProviderEnabled(LocationManager.GPS_PROVIDER)) {

            // Temos permissão, mas o GPS não está ativado. Pergunte ao usuário se ele gostaria de acessar as configurações de localização.
            AlertDialogGPS gpsSettings = new AlertDialogGPS();
            gpsSettings.show(fm, "Alert Dialog");

            // O GPS não foi ativado com o pressionar do botão, por isso, verifique se ele ainda é falso.
            isToggleRecordingButtonClicked = false;

        } else {

            // Tem permissão e o GPS está ativado, vamos começar a registrar.
            // Registra o ouvinte no Gerenciador de localização para receber atualizações de localização apenas do GPS.
            // O segundo parâmetro controla o intervalo de tempo mínimo entre as notificações e o terceiro é a alteração mínima na
            // distância entre notificações - definir ambos como zero quando solicita notificações de localização com a maior frequência possível.
            locationManager.requestLocationUpdates(
                    LocationManager.GPS_PROVIDER, 0, 0, this);

            // Iniciado com sucesso o registro do GPS, define o botão como clicado.
            isToggleRecordingButtonClicked = true;

            // Estamos prontos para iniciar o registro, vamos criar um novo objeto SegmentHandler.
            segmentHandler = new SegmentHandler(this, SensorManager);
            segmentHandler.setSomeEventListener(this);
        }
    }


    //******************************************************************************************************************
    //                                                INÍCIO  DA BARRA DO APLICATIVO
    //******************************************************************************************************************

    /**
     * Adiciona entradas à barra de ação.
     * Adiciona todas as entradas, como configurações, ao menu suspenso da barra de ação.
     *
     * @param menu
     * @return
     */
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.my_toolbar_menu, menu);
        return true;
    }

    /**
     * Retorno de chamada de itens da barra de aplicativos
     *
     * Esse método é chamado quando o usuário seleciona um dos itens da barra de aplicativos e passa um objeto de Item de Menu para indicar
     * qual item foi clicado. O ID retornado de MenutItem.getItemId () corresponde ao ID que você declarou para a barra de aplicativos
     * em item res/menu/ <- menu.xml->
     *
     * @param item MenuItem retorna o objeto para indicar qual item foi clicado. Usa MenuItem.getItemId () para obter valor.
     * @return
     */
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case R.id.action_settings:
                // O usuário escolhe o item Configurações, mostra a interface do usuário das configurações do aplicativo.

                getSupportFragmentManager()
                        .beginTransaction()
                        .replace(R.id.preferenceFragment, new SettingsFragment())
                        .addToBackStack(null)
                        .commit();

                return true;

            default:
                // Se chegar aqui, a ação do usuário não foi reconhecida.
                // Invoca a superclasse para lidar com isso.
                return super.onOptionsItemSelected(item);
        }
    }



    // TODO: O que é isso? É assim que você obtém as preferências que estavam nas configurações de algum modo.
    private void getLoggingSettings() {

        SharedPreferences settings = getDefaultSharedPreferences(this);

        // Obtenha configurações sobre o tipo de arquivo.
        boolean isEsriJASON = settings.getBoolean("preference_filename_json", false);
        String loggingFilePrefix = settings.getString("preference_filename_prefix", "IRICalculado");

        // Obtem as configurações sobre as variáveis de log.
        boolean loggingUnits = settings.getBoolean("preference_logging_units", true);
        int maxLoggingDistance = Integer.parseInt(
                settings.getString("preference_logging_distance", "1000"));
        int maxLoggingSpeed = Integer.parseInt(
                settings.getString("preference_logging_max_Speed", "80"));
        int minLoggingSpeed = Integer.parseInt(
                settings.getString("preference_logging_min_speed", "20"));

    }

    //******************************************************************************************************************
    //                                            INÍCIA O RETORNO DOS SENSORES
    //******************************************************************************************************************

    //*********************************************   Acelerômetro  ***************************************************

    @Override
    public void onSensorChanged(SensorEvent sensorEvent) {
        int sensorType = sensorEvent.sensor.getType();

        switch (sensorType) {
            case Sensor.TYPE_ACCELEROMETER:

                // TODO: Os dados devem ser removidos desse método o mais rápido possível.
                AccelerometerData = sensorEvent.values.clone();

                float alpha = 0.8f;

                // Filtro low-pass para isolar a gravidade.
                adjustedGravity[0] = alpha * GravityData[0] + (1 - alpha) *  AccelerometerData[0];
                adjustedGravity[1] = alpha * GravityData[1] + (1 - alpha) *  AccelerometerData[1];
                adjustedGravity[2] = alpha * GravityData[2] + (1 - alpha) *  AccelerometerData[2];

                // Filtro High-pass para remover a gravidade.
                linear_acceleration[0] =  AccelerometerData[0] - adjustedGravity[0];
                linear_acceleration[1] =  AccelerometerData[1] - adjustedGravity[1];
                linear_acceleration[2] =  AccelerometerData[2] - adjustedGravity[2];


                // O objeto segmentHandler é criado no método enableGPS () quando o usuário pressiona o botão de  log de início
                // Se o objeto segmentHandler existir, significa que temos permissões de localização, o GPS é
                // ativado e precisamos passar o acelerômetro SensorEvent para o SegmentHandler.
                if (segmentHandler != null) {
                    segmentHandler.setSurfaceDoctorAccelerometer(sensorEvent);
                }
                break;

            case Sensor.TYPE_MAGNETIC_FIELD:
                MagnetometerData = sensorEvent.values.clone();

                if ( segmentHandler != null ) {
                    segmentHandler.setSurfaceDoctorMagnetometer(sensorEvent);
                }
                break;
            case Sensor.TYPE_GRAVITY:
                GravityData = sensorEvent.values.clone();

                if ( segmentHandler != null ) {
                    segmentHandler.setSurfaceDoctorGravity(sensorEvent);
                }

                break;
            default:
                return;
        }


        // Obtem os valores do acelerômetro do telefone no sistema de coordenadas da Terra.
        //
        // X = Leste / Oeste
        // Y = Norte / Sul
        // Z = Para cima / Para baixo
        float[] earthAcc = VectorAlgebra.earthAccelerometer(
                linear_acceleration, MagnetometerData,
                GravityData, SensorManager);

        // TODO: Também precisamos de dados do acelerômetro no sistema de coordenadas do usuário, onde y está sempre em frente.

        // Obtem a orientação do telefone - em radianos.
        float[] phoneOrientationValuesRadians = VectorAlgebra.phoneOrientation(
                AccelerometerData, MagnetometerData, SensorManager);

        // A orientação do telefone é dada em radianos, vamos converter isso em graus.
        double[] phoneOrientationValuesDegrees = VectorAlgebra.radiansToDegrees(phoneOrientationValuesRadians);


        // Exibe os dados do acelerômetro do telefone na View.
        TextSensorPhoneAccX.setText(getResources().getString(
                R.string.value_format, linear_acceleration[0]));
        TextSensorPhoneAccY.setText(getResources().getString(
                R.string.value_format, linear_acceleration[1]));
        TextSensorPhoneAccZ.setText(getResources().getString(
                R.string.value_format, linear_acceleration[2]));

        // Exibe os dados do acelerômetro do telefone no sistema de coordenadas da Terra.
        TextSensorEarthAccX.setText(getResources().getString(
                R.string.value_format, earthAcc[0]));
        TextSensorEarthAccY.setText(getResources().getString(
                R.string.value_format, earthAcc[1]));
        TextSensorEarthAccZ.setText(getResources().getString(
                R.string.value_format, earthAcc[2]));

        // Exibe os dados de orientação do telefone na View.
        TextSensorPhoneAzimuth.setText(getResources().getString(
                R.string.value_format, phoneOrientationValuesDegrees[0]));
        TextSensorPhonePitch.setText(getResources().getString(
                R.string.value_format, phoneOrientationValuesDegrees[1]));
        TextSensorPhoneRoll.setText(getResources().getString(
                R.string.value_format, phoneOrientationValuesDegrees[2]));

    }


    /**
     * Retorno do Android para alteração da precisão do acelerômetro.
     * <p>
     * Deve ser implementado para satisfazer a interface SensorEventListener;
     * não utilizado neste aplicativo.
     */
    @Override
    public void onAccuracyChanged(Sensor sensor, int i) {


    }


    //*********************************************  Localização   *******************************************************

    /**
     * Retorno do Android para localização GPS
     *
     * @param location
     */
    @Override
    public void onLocationChanged(Location location) {

        // O objeto segmentHandler é criado no método enableGPS () quando o usuário pressiona o log de início
        // Se o objeto segmentHandler existir, significa que temos permissões de localização, o GPS é
        // ativado e precisamos passar a localização do GPS para o SegmentHandler.
        if (segmentHandler != null) {
            segmentHandler.setSurfaceDoctorLocation(location);
        }
    }


    // Chamado quando o status do provedor é alterado. Esse método é chamado quando um provedor não consegue buscar um local
    // ou se o provedor ficou disponível recentemente após um período de indisponibilidade.
    @Override
    public void onStatusChanged(String provider, int status, Bundle extras) {
        Log.i("Location", "onSatusChanged fired");
    }


    // Chamado quando o provedor é ativado pelo usuário
    @Override
    public void onProviderEnabled(String provider) {
        // TODO: remove a mensagem de que o aplicativo não funcionará com o GPS desativado.
        Log.i("Location", "onProviderEnabled fired");
    }


    // Chamado quando o fornecedor é desativado pelo usuário. Se requestLocationUpdates for chamado em um já desativado
    // provedor, esse método é chamado imediatamente.
    @Override
    public void onProviderDisabled(String provider) {
        // TODO: adiciona a mensagem de que o aplicativo não funcionará com o GPS desativado e solicite a ativação.

        // Temos permissão, mas o GPS está desativado. Permite solicitar ao usuário para ativá-lo.
        enableGPS();

    }


    //******************************************************************************************************************
    //                                            Surface Doctor
    //******************************************************************************************************************


    /**
     * Evento de SegmentHandler
     *
     * @param surfaceDoctorEvent
     */
    @Override
    public void onSurfaceDoctorEvent(SurfaceDoctorEvent surfaceDoctorEvent) {
        String surfaceDoctorEventType = surfaceDoctorEvent.getType();

        switch (surfaceDoctorEventType) {
            case "TYPE_SEGMENT_IRI":
                TextView x = findViewById(R.id.last_IRI_x);
                TextView y = findViewById(R.id.last_IRI_y);
                TextView z = findViewById(R.id.last_IRI_z);

                x.setText(Double.toString(surfaceDoctorEvent.x));
                y.setText(Double.toString(surfaceDoctorEvent.y));
                z.setText(Double.toString(surfaceDoctorEvent.z));
        }
    }

}