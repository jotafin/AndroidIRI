package SurfaceDoctor;

public interface SurfaceDoctorInterface {

    void onSurfaceDoctorEvent(SurfaceDoctorEvent surfaceDoctorEvent);
}
