package SurfaceDoctor;

public class SurfaceDoctorEvent {
    // TYPE_SEGMENT_IRI


    public String type;

    // Valores totais de IRI
    public double x;
    public double y;
    public double z;

    public double distance;

    public String getType() { return type;}
}
