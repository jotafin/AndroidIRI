package com.northbridgeanalytics.mysensors;

import org.junit.Test;

import static org.junit.Assert.*;

/**
 * Exemplo de teste de unidade local, que será executado na máquina de desenvolvimento (host).
 *
 * @see <a href="http://d.android.com/tools/testing">Documentação de teste</a>
 */
public class ExampleUnitTest {
    @Test
    public void addition_isCorrect() {
        assertEquals(4, 2 + 2);
    }
}